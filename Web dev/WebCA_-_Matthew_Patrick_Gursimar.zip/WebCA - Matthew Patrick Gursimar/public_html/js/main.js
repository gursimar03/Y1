/* 
 Web Development CA 4
 Created on : 25 Apr 2022, 09:57:15
 Author     : Gursimar, Patrick, Matthew
 Group      : SD1c
 */

// Date Function, adapted from: https://www.w3schools.com/jsref/jsref_obj_date.asp
let clock = new Date();
document.getElementById("date").innerHTML = clock.toUTCString()



