package SummerExam;

/**
 *
 * @author Your Own Name HERE
 */
public class FitnessTracker {
    private String trackerType;
    private String ownerName;
    
    public FitnessTracker()
    {
        this.trackerType = "";
        this.ownerName = "";
    }

    public String getTrackerType() {
        return trackerType;
    }

    public String getOwnerName() {
        return ownerName;
    }
    
    public void setTrackerType(String trackerType) {
        this.trackerType = trackerType;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
    
    @Override
    public String toString()
    {
        return "Fitness Tracker{" + "Type=" + trackerType + ", Owner's Name=" + ownerName + '}';
    }
    
}
