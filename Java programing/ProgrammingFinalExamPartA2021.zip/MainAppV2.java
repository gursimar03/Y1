
package SummerExam;

/**
 *
 * @author Your Own Name HERE
 */
    public class MainAppV2
{
    public static void main(String[] args)
    {
       
        Activity a1 = new Activity(34.5, "01/05/2021", "08:17",true);  
        Activity a2 = new Activity(68.1, "28/04/2021", "12:43",false);  
        Activity a3 = new Activity(23.2, "01/05/2021", "20:34",true);  
        Activity a4 = new Activity(17.8, "05/05/2021", "11:00",true);  
        
        
        
//  Tests for Question 3 (a) & (b) & (c) 
        
        
        
        
        
        
//   Test for Question 3 (e)  
        
  
        
//        
//
//   Test for Question 4 (a)
//


  
//
//   Test for Question 4 (b)
//


//
//   Test for Question 4 (c)
//


//
//   Test for Question 4 (d)
//
        
        
       
//
//   Test for Question 4 (e)
//



  
    }
    

}
    

