package SummerExam;

/**
 *
 * @author Your Own Name HERE
 */
public class Activity{
    
    private double duration;//in minutes
    private String date;//use format DD/MM/YYYY
    private String time;//use HH:MM
    private boolean map;//map is true if the activity was started by the user with GPS connected to their phone and false if it was automatically registered 
    
    public Activity(double duration, String date, String time,boolean map)
    {
        this.duration = duration;
        this.date = date;
        this.time = time;
        this.map = map;
    }

    public double getDuration() {
        return duration;
    }
    
    public String getDate() {
        return date;
    }
    
    public String getTime() {
        return time;
    }
    
    public boolean isMap() {
        return map;
    }
    
    public void setDuration(double duration) {
        this.duration = duration;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setMap(boolean map) {
        this.map = map;
    }
    
    @Override
    public String toString()
    {
        return "Activity{" + "Duration:" + duration + "; Date: "+date+"; Time: "+time+"; Map: " + map + '}';
    }
    
    
}
